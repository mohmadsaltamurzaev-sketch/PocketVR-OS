# PocketVR OS v2.1 (Optimized)

Нативный Android VR/AR-лаунчер на Kotlin + OpenGL ES 2.0, оптимизированный под Snapdragon 720G (Zero-GC render loop, переиспользование буферов MediaPipe, пауза VR-движка при открытом WebView).

## Сборка готового APK

### Вариант 1: Через GitHub Actions (без ПК и Android Studio)
1. Загрузи все файлы архива (включая `.github/workflows/build.yml`) в свой репозиторий GitHub.
2. Перейди в **Actions** -> **Build PocketVR OS APK** -> **Run workflow**.
3. Скачай артефакт **`PocketVR-OS-v2-APK`** и установи `app-debug.apk` на телефон.

### Вариант 2: Локально (в Antigravity / Android Studio / терминале)
Запусти команду в корне проекта:
```bash
chmod +x build_apk.sh && ./build_apk.sh
```
Готовый файл появится по пути `app/build/outputs/apk/debug/app-debug.apk`.
