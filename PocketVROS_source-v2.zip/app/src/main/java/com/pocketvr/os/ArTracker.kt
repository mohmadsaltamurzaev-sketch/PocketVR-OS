package com.pocketvr.os

import android.app.Activity
import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.opengl.Matrix
import com.google.ar.core.ArCoreApk
import com.google.ar.core.Config
import com.google.ar.core.Session
import com.google.ar.core.TrackingState
import kotlin.math.sqrt

class ArTracker(private val activity: Activity) : SensorEventListener {

    private var arSession: Session? = null
    private val sensorManager = activity.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val rotSensor: Sensor? = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)

    @Volatile var is6DofActive: Boolean = false
        private set

    @Volatile var statusText: String = "3DoF Gyro"
        private set

    // Pre-allocated scratch buffers (Zero GC in render/sensor loops)
    val position = floatArrayOf(0f, 0f, 0f)
    private val targetQuat = floatArrayOf(0f, 0f, 0f, 1f)
    val smoothQuat = floatArrayOf(0f, 0f, 0f, 1f)
    private val sensorQuat = FloatArray(4)
    private val rotMat = FloatArray(16)
    private val dragMat = FloatArray(16)

    @Volatile var yawOffset = 0f
    @Volatile var pitchOffset = 0f

    fun start(enable6Dof: Boolean) {
        rotSensor?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
        if (enable6Dof) {
            tryInitArCore()
        } else {
            is6DofActive = false
            statusText = "3DoF Gyro"
        }
    }

    private fun tryInitArCore() {
        try {
            val availability = ArCoreApk.getInstance().checkAvailability(activity)
            if (availability.isSupported) {
                if (arSession == null) {
                    arSession = Session(activity).apply {
                        val cfg = Config(this)
                        cfg.updateMode = Config.UpdateMode.LATEST_CAMERA_IMAGE
                        cfg.focusMode = Config.FocusMode.FIXED
                        cfg.planeFindingMode = Config.PlaneFindingMode.DISABLED
                        cfg.lightEstimationMode = Config.LightEstimationMode.DISABLED
                        configure(cfg)
                    }
                }
                arSession?.resume()
                is6DofActive = true
                statusText = "ARCore 6DoF Ready"
            } else {
                is6DofActive = false
                statusText = "3DoF Fallback"
            }
        } catch (_: Exception) {
            is6DofActive = false
            statusText = "3DoF Fallback"
        }
    }

    fun pause() {
        sensorManager.unregisterListener(this)
        try { arSession?.pause() } catch (_: Exception) {}
    }

    fun updateFrame() {
        if (is6DofActive && arSession != null) {
            try {
                val frame = arSession!!.update()
                val cam = frame.camera
                if (cam.trackingState == TrackingState.TRACKING) {
                    val pose = cam.displayOrientedPose
                    position[0] = pose.tx()
                    position[1] = pose.ty()
                    position[2] = pose.tz()
                    pose.getRotationQuaternion(targetQuat, 0)
                    statusText = "ARCore 6DoF"
                }
            } catch (_: Exception) {}
        }
        slerp(smoothQuat, targetQuat, 0.18f)
    }

    fun recenter() {
        position[0] = 0f; position[1] = 0f; position[2] = 0f
        yawOffset = 0f; pitchOffset = 0f
    }

    fun getHeadRotationMatrix(out: FloatArray) {
        quatToMatrix(smoothQuat, rotMat)
        Matrix.setIdentityM(dragMat, 0)
        Matrix.rotateM(dragMat, 0, pitchOffset, 1f, 0f, 0f)
        Matrix.rotateM(dragMat, 0, yawOffset, 0f, 1f, 0f)
        Matrix.multiplyMM(out, 0, dragMat, 0, rotMat, 0)
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type == Sensor.TYPE_ROTATION_VECTOR && (!is6DofActive || statusText != "ARCore 6DoF")) {
            SensorManager.getQuaternionFromVector(sensorQuat, event.values)
            targetQuat[0] = sensorQuat[1]
            targetQuat[1] = sensorQuat[2]
            targetQuat[2] = sensorQuat[3]
            targetQuat[3] = sensorQuat[0]
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun slerp(curr: FloatArray, target: FloatArray, t: Float) {
        var dot = curr[0] * target[0] + curr[1] * target[1] + curr[2] * target[2] + curr[3] * target[3]
        var tx = target[0]; var ty = target[1]; var tz = target[2]; var tw = target[3]
        if (dot < 0f) {
            dot = -dot; tx = -tx; ty = -ty; tz = -tz; tw = -tw
        }
        curr[0] += (tx - curr[0]) * t
        curr[1] += (ty - curr[1]) * t
        curr[2] += (tz - curr[2]) * t
        curr[3] += (tw - curr[3]) * t
        val len = sqrt(curr[0] * curr[0] + curr[1] * curr[1] + curr[2] * curr[2] + curr[3] * curr[3])
        if (len > 1e-6f) {
            val inv = 1f / len
            curr[0] *= inv; curr[1] *= inv; curr[2] *= inv; curr[3] *= inv
        }
    }

    private fun quatToMatrix(q: FloatArray, m: FloatArray) {
        val x = q[0]; val y = q[1]; val z = q[2]; val w = q[3]
        val xx = x * x; val yy = y * y; val zz = z * z
        val xy = x * y; val xz = x * z; val yz = y * z
        val wx = w * x; val wy = w * y; val wz = w * z
        m[0] = 1f - 2f * (yy + zz); m[1] = 2f * (xy + wz); m[2] = 2f * (xz - wy); m[3] = 0f
        m[4] = 2f * (xy - wz); m[5] = 1f - 2f * (xx + zz); m[6] = 2f * (yz + wx); m[7] = 0f
        m[8] = 2f * (xz + wy); m[9] = 2f * (yz - wx); m[10] = 1f - 2f * (xx + yy); m[11] = 0f
        m[12] = 0f; m[13] = 0f; m[14] = 0f; m[15] = 1f
    }
}
