package com.pocketvr.os

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View

class HandOverlay(context: Context) : View(context) {

    var handState: HandState = HandState()
        set(value) {
            field = value
            postInvalidate()
        }

    var stereoMode: Boolean = false
        set(value) {
            field = value
            postInvalidate()
        }

    private val reticlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xDD00E5FF.toInt()
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }
    private val pinchFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xAA00E676.toInt()
        style = Paint.Style.FILL
    }
    private val jointPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xCCFFFFFF.toInt()
        style = Paint.Style.FILL
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()

        if (stereoMode) {
            drawEyeOverlay(canvas, 0f, w * 0.5f, h)
            drawEyeOverlay(canvas, w * 0.5f, w * 0.5f, h)
        } else {
            drawEyeOverlay(canvas, 0f, w, h)
        }
    }

    private fun drawEyeOverlay(canvas: Canvas, offsetX: Float, eyeW: Float, eyeH: Float) {
        val cx = offsetX + eyeW * 0.5f
        val cy = eyeH * 0.5f
        canvas.drawCircle(cx, cy, 7f, reticlePaint)

        val hs = handState
        if (hs.detected) {
            val px = offsetX + hs.pointerX * eyeW
            val py = hs.pointerY * eyeH
            if (hs.isPinching) {
                canvas.drawCircle(px, py, 18f, pinchFill)
            }
            canvas.drawCircle(px, py, 20f, reticlePaint)
            for (pt in hs.landmarks) {
                canvas.drawCircle(offsetX + pt.first * eyeW, pt.second * eyeH, 4f, jointPaint)
            }
        }
    }
}
