package com.pocketvr.os

import android.content.Context
import android.graphics.Bitmap
import android.os.SystemClock
import android.util.Size
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import java.util.concurrent.Executors
import kotlin.math.hypot

data class HandState(
    val detected: Boolean = false,
    val pointerX: Float = 0.5f,
    val pointerY: Float = 0.5f,
    val isPinching: Boolean = false,
    val landmarks: List<Pair<Float, Float>> = emptyList()
)

class HandTracker(
    private val context: Context,
    private val onHandUpdate: (HandState) -> Unit
) {
    private var handLandmarker: HandLandmarker? = null
    private val executor = Executors.newSingleThreadExecutor()
    private var cameraProvider: ProcessCameraProvider? = null

    // Reusable bitmap to avoid GC churn on every camera frame
    private var reusableBitmap: Bitmap? = null
    private var lastInferMs: Long = 0L
    private val minInferIntervalMs = 42L // ~24 Hz hand inference -> keeps GPU/CPU free for 60+ FPS VR

    @Volatile var statusText: String = "Hands Off"
        private set

    fun start(lifecycleOwner: LifecycleOwner) {
        try {
            val baseOptions = BaseOptions.builder()
                .setModelAssetPath("hand_landmarker.task")
                .setDelegate(Delegate.CPU)
                .build()
            val options = HandLandmarker.HandLandmarkerOptions.builder()
                .setBaseOptions(baseOptions)
                .setRunningMode(RunningMode.LIVE_STREAM)
                .setNumHands(1)
                .setMinHandDetectionConfidence(0.55f)
                .setMinTrackingConfidence(0.55f)
                .setResultListener { result, _ -> processResult(result) }
                .build()
            handLandmarker = HandLandmarker.createFromOptions(context, options)
            statusText = "MediaPipe Hands"
            bindCamera(lifecycleOwner)
        } catch (_: Exception) {
            statusText = "Hands Fallback"
            onHandUpdate(HandState(detected = false))
        }
    }

    @Suppress("DEPRECATION")
    private fun bindCamera(lifecycleOwner: LifecycleOwner) {
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            try {
                cameraProvider = future.get()
                val analyzer = ImageAnalysis.Builder()
                    .setTargetResolution(Size(320, 240))
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .build()

                analyzer.setAnalyzer(executor) { imageProxy ->
                    try {
                        val now = SystemClock.uptimeMillis()
                        if (now - lastInferMs >= minInferIntervalMs) {
                            lastInferMs = now
                            val w = imageProxy.width
                            val h = imageProxy.height
                            var bmp = reusableBitmap
                            if (bmp == null || bmp.width != w || bmp.height != h) {
                                bmp?.recycle()
                                bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                                reusableBitmap = bmp
                            }
                            bmp.copyPixelsFromBuffer(imageProxy.planes[0].buffer)
                            val mpImage = BitmapImageBuilder(bmp).build()
                            handLandmarker?.detectAsync(mpImage, now)
                        }
                    } catch (_: Exception) {
                    } finally {
                        imageProxy.close()
                    }
                }

                cameraProvider?.unbindAll()
                cameraProvider?.bindToLifecycle(
                    lifecycleOwner,
                    CameraSelector.DEFAULT_BACK_CAMERA,
                    analyzer
                )
            } catch (_: Exception) {
                statusText = "Cam Busy (ARCore)"
            }
        }, ContextCompat.getMainExecutor(context))
    }

    private fun processResult(result: HandLandmarkerResult) {
        val hands = result.landmarks()
        if (hands.isEmpty()) {
            onHandUpdate(HandState(detected = false))
            return
        }
        val lm = hands[0]
        val thumbTip = lm[4]
        val indexTip = lm[8]
        val pinchDist = hypot(
            (thumbTip.x() - indexTip.x()).toDouble(),
            (thumbTip.y() - indexTip.y()).toDouble()
        ).toFloat()

        val pts = ArrayList<Pair<Float, Float>>(lm.size)
        for (i in lm.indices) {
            pts.add(Pair(lm[i].x(), lm[i].y()))
        }
        onHandUpdate(
            HandState(
                detected = true,
                pointerX = indexTip.x().coerceIn(0f, 1f),
                pointerY = indexTip.y().coerceIn(0f, 1f),
                isPinching = pinchDist < 0.055f,
                landmarks = pts
            )
        )
    }

    fun stop() {
        try { cameraProvider?.unbindAll() } catch (_: Exception) {}
        try { handLandmarker?.close() } catch (_: Exception) {}
        handLandmarker = null
        statusText = "Hands Off"
    }
}
