package com.pocketvr.os

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.graphics.Color
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.view.*
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var arTracker: ArTracker
    private lateinit var handTracker: HandTracker
    private lateinit var handOverlay: HandOverlay
    private lateinit var uiPanel: UiPanel
    private lateinit var glView: GLSurfaceView

    private lateinit var webContainer: LinearLayout
    private lateinit var webView: WebView
    private lateinit var webTitle: TextView

    private var lastTouchX = 0f
    private var lastTouchY = 0f
    private var isDragging = false
    private var wasPinching = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        hideSystemUi()

        prefs = Prefs(this)
        arTracker = ArTracker(this)
        handOverlay = HandOverlay(this).apply { stereoMode = prefs.stereoEnabled }

        uiPanel = UiPanel(
            context = this,
            prefs = prefs,
            onLaunchUrl = { title, url -> runOnUiThread { openWebApp(title, url) } },
            onAddCustomAppDialog = { runOnUiThread { showAddAppDialog() } },
            onToggleStereo = {
                prefs.stereoEnabled = !prefs.stereoEnabled
                handOverlay.stereoMode = prefs.stereoEnabled
            },
            onRecenter = { arTracker.recenter() },
            onToggle6Dof = {
                prefs.ar6DofEnabled = !prefs.ar6DofEnabled
                arTracker.pause()
                arTracker.start(prefs.ar6DofEnabled)
            },
            onToggleHands = {
                prefs.handTrackingEnabled = !prefs.handTrackingEnabled
                if (prefs.handTrackingEnabled) handTracker.start(this) else handTracker.stop()
                uiPanel.handStatus = handTracker.statusText
            }
        )

        handTracker = HandTracker(this) { state ->
            handOverlay.handState = state
            uiPanel.handStatus = handTracker.statusText
            if (state.detected && webContainer.visibility != View.VISIBLE) {
                uiPanel.updateHover(state.pointerX, state.pointerY)
                if (state.isPinching && !wasPinching) {
                    uiPanel.handleClick(state.pointerX, state.pointerY)
                }
                wasPinching = state.isPinching
            }
        }

        val root = FrameLayout(this)

        glView = GLSurfaceView(this).apply {
            setEGLContextClientVersion(2)
            setRenderer(VrRenderer(prefs, arTracker, uiPanel))
            renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
        }
        root.addView(glView)
        root.addView(handOverlay)

        webContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF0A0F18.toInt())
            visibility = View.GONE
        }

        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(0xFF131B29.toInt())
            setPadding(24, 12, 24, 12)
            gravity = Gravity.CENTER_VERTICAL
        }

        val btnBack = Button(this).apply {
            text = "< BACK"
            setTextColor(Color.WHITE)
            setBackgroundColor(0xFF263238.toInt())
            setOnClickListener { if (webView.canGoBack()) webView.goBack() }
        }
        webTitle = TextView(this).apply {
            text = "PocketVR Browser"
            setTextColor(0xFF00E5FF.toInt())
            textSize = 18f
            setPadding(28, 0, 28, 0)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val btnClose = Button(this).apply {
            text = "HOME VR"
            setTextColor(Color.BLACK)
            setBackgroundColor(0xFF00E5FF.toInt())
            setOnClickListener { closeWebApp() }
        }

        topBar.addView(btnBack)
        topBar.addView(webTitle)
        topBar.addView(btnClose)

        webView = WebView(this).apply {
            setLayerType(View.LAYER_TYPE_HARDWARE, null)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.cacheMode = WebSettings.LOAD_DEFAULT
            settings.mediaPlaybackRequiresUserGesture = false
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            settings.userAgentString =
                "Mozilla/5.0 (Linux; Android 13; PocketVR OS) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
            )
        }

        webContainer.addView(topBar)
        webContainer.addView(webView)
        root.addView(webContainer)

        setContentView(root)
        requestCameraIfNeeded()
    }

    private fun openWebApp(title: String, url: String) {
        // Pause VR rendering & hand tracking while full-screen WebView is active
        handTracker.stop()
        glView.onPause()
        webTitle.text = title
        webView.onResume()
        webView.loadUrl(url)
        webContainer.visibility = View.VISIBLE
    }

    private fun closeWebApp() {
        webContainer.visibility = View.GONE
        webView.loadUrl("about:blank")
        webView.onPause()
        glView.onResume()
        if (prefs.handTrackingEnabled &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            handTracker.start(this)
        }
        hideSystemUi()
    }

    private fun showAddAppDialog() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 12)
        }
        val nameInput = EditText(this).apply { hint = "Game / App Name (e.g. Discord)" }
        val urlInput = EditText(this).apply { hint = "URL (e.g. https://discord.com/app)" }
        layout.addView(nameInput)
        layout.addView(urlInput)

        AlertDialog.Builder(this)
            .setTitle("Add to Pocket Store")
            .setView(layout)
            .setPositiveButton("ADD") { _, _ ->
                val title = nameInput.text.toString().trim()
                var url = urlInput.text.toString().trim()
                if (title.isNotEmpty() && url.isNotEmpty()) {
                    if (!url.startsWith("http")) url = "https://$url"
                    prefs.addCustomApp(
                        StoreItem(
                            id = "custom_${System.currentTimeMillis()}",
                            title = title,
                            category = "GAME",
                            url = url,
                            accentColor = 0xFF00E5FF.toInt(),
                            iconType = "GAME",
                            description = "Added by User"
                        )
                    )
                    uiPanel.dirty = true
                }
            }
            .setNegativeButton("CANCEL", null)
            .show()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (webContainer.visibility == View.VISIBLE) return super.onTouchEvent(event)
        val w = glView.width.coerceAtLeast(1).toFloat()
        val h = glView.height.coerceAtLeast(1).toFloat()
        val nx = if (prefs.stereoEnabled) ((event.x % (w * 0.5f)) / (w * 0.5f)) else (event.x / w)
        val ny = event.y / h

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                lastTouchX = event.x; lastTouchY = event.y
                isDragging = false
                uiPanel.updateHover(nx, ny)
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.x - lastTouchX
                val dy = event.y - lastTouchY
                if (kotlin.math.abs(dx) > 10f || kotlin.math.abs(dy) > 10f) {
                    isDragging = true
                    arTracker.yawOffset += dx * 0.12f
                    arTracker.pitchOffset = (arTracker.pitchOffset + dy * 0.12f).coerceIn(-60f, 60f)
                    lastTouchX = event.x; lastTouchY = event.y
                }
            }
            MotionEvent.ACTION_UP -> {
                if (!isDragging) uiPanel.handleClick(nx, ny)
            }
        }
        return true
    }

    private fun requestCameraIfNeeded() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 101)
        }
    }

    override fun onResume() {
        super.onResume()
        if (webContainer.visibility != View.VISIBLE) {
            glView.onResume()
            arTracker.start(prefs.ar6DofEnabled)
            if (prefs.handTrackingEnabled &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                handTracker.start(this)
            }
            uiPanel.handStatus = handTracker.statusText
        }
    }

    override fun onPause() {
        super.onPause()
        handTracker.stop()
        arTracker.pause()
        glView.onPause()
    }

    private fun hideSystemUi() {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
        )
    }
}
