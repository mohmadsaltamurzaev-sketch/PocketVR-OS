package com.pocketvr.os

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("pocketvr_os_prefs", Context.MODE_PRIVATE)

    @Volatile var stereoEnabled: Boolean = sp.getBoolean("stereo_enabled", false)
        set(v) {
            field = v
            sp.edit().putBoolean("stereo_enabled", v).apply()
        }

    @Volatile var ipdMm: Float = sp.getFloat("ipd_mm", 64f)
        set(v) {
            val clamped = v.coerceIn(54f, 74f)
            field = clamped
            sp.edit().putFloat("ipd_mm", clamped).apply()
        }

    @Volatile var ar6DofEnabled: Boolean = sp.getBoolean("ar_6dof", true)
        set(v) {
            field = v
            sp.edit().putBoolean("ar_6dof", v).apply()
        }

    @Volatile var handTrackingEnabled: Boolean = sp.getBoolean("hand_tracking", true)
        set(v) {
            field = v
            sp.edit().putBoolean("hand_tracking", v).apply()
        }

    @Volatile var proUnlocked: Boolean = sp.getBoolean("pro_unlocked", false)
        set(v) {
            field = v
            sp.edit().putBoolean("pro_unlocked", v).apply()
        }

    fun getInstalledIds(): MutableSet<String> {
        val raw = sp.getStringSet("installed_apps", setOf("telegram", "google", "youtube")) ?: emptySet()
        return raw.toMutableSet()
    }

    fun setInstalled(id: String, installed: Boolean) {
        val set = getInstalledIds()
        if (installed) set.add(id) else set.remove(id)
        sp.edit().putStringSet("installed_apps", set).apply()
    }

    fun getCustomApps(): MutableList<StoreItem> {
        val json = sp.getString("custom_apps_json", "[]") ?: "[]"
        val arr = JSONArray(json)
        val list = mutableListOf<StoreItem>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list.add(
                StoreItem(
                    id = o.getString("id"),
                    title = o.getString("title"),
                    category = o.optString("category", "GAME"),
                    url = o.getString("url"),
                    accentColor = o.optInt("accentColor", 0xFF00E5FF.toInt()),
                    iconType = o.optString("iconType", "GAME"),
                    description = o.optString("description", "Custom Pocket Store App")
                )
            )
        }
        return list
    }

    fun addCustomApp(item: StoreItem) {
        val list = getCustomApps()
        list.add(item)
        val arr = JSONArray()
        for (it in list) {
            val o = JSONObject()
            o.put("id", it.id)
            o.put("title", it.title)
            o.put("category", it.category)
            o.put("url", it.url)
            o.put("accentColor", it.accentColor)
            o.put("iconType", it.iconType)
            o.put("description", it.description)
            arr.put(o)
        }
        sp.edit().putString("custom_apps_json", arr.toString()).apply()
        setInstalled(item.id, true)
    }
}
