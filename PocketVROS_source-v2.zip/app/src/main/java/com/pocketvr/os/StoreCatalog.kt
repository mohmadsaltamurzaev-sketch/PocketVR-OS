package com.pocketvr.os

data class StoreItem(
    val id: String,
    val title: String,
    val category: String,
    val url: String,
    val accentColor: Int,
    val iconType: String,
    val description: String
)

object StoreCatalog {
    val defaultItems: List<StoreItem> = listOf(
        StoreItem("telegram", "Telegram", "APP", "https://web.telegram.org/k/", 0xFF29B6F6.toInt(), "TELEGRAM", "Official Telegram Web Messenger"),
        StoreItem("google", "Google", "APP", "https://www.google.com/", 0xFF4CAF50.toInt(), "GOOGLE", "Google Search & Spatial Browser"),
        StoreItem("youtube", "YouTube", "APP", "https://m.youtube.com/", 0xFFFF5252.toInt(), "YOUTUBE", "YouTube Cinema & 360 Video"),
        StoreItem("moonrider", "Moon Rider VR", "GAME", "https://moonrider.xyz/", 0xFFE040FB.toInt(), "GAME", "WebXR Rhythm Saber Game"),
        StoreItem("hextris", "Hextris 3D", "GAME", "https://hextris.io/", 0xFFFFB74D.toInt(), "CUBE", "Fast-paced Spatial Arcade Puzzle"),
        StoreItem("aframe_shooter", "A-Blast VR", "GAME", "https://aframe.io/a-blast/", 0xFF00E676.toInt(), "TARGET", "WebVR Target Shooter"),
        StoreItem("gemini_ai", "AI Prompt Hub", "AI", "https://gemini.google.com/", 0xFF40C4FF.toInt(), "PROMPT", "Interactive AI Assistant & Prompts")
    )

    fun getAll(prefs: Prefs): List<StoreItem> = defaultItems + prefs.getCustomApps()
}
