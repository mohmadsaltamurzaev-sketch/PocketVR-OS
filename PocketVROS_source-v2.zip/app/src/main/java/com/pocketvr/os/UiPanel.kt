package com.pocketvr.os

import android.content.Context
import android.graphics.*
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.SystemClock
import android.view.InputDevice
import java.text.SimpleDateFormat
import java.util.*

enum class PanelTab { HOME, STORE, CONNECTIONS, PROMPT }

data class HitButton(
    val id: String,
    val rect: RectF,
    val action: () -> Unit
)

class UiPanel(
    private val context: Context,
    private val prefs: Prefs,
    private val onLaunchUrl: (title: String, url: String) -> Unit,
    private val onAddCustomAppDialog: () -> Unit,
    private val onToggleStereo: () -> Unit,
    private val onRecenter: () -> Unit,
    private val onToggle6Dof: () -> Unit,
    private val onToggleHands: () -> Unit
) {
    val width = 1280
    val height = 720
    val bitmap: Bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    private val canvas = Canvas(bitmap)

    @Volatile var currentTab: PanelTab = PanelTab.HOME
    @Volatile var arStatus: String = "ARCore 6DoF"
    @Volatile var handStatus: String = "MediaPipe Hands"
    @Volatile var fps: Int = 60
    @Volatile var hoverX: Float = -1f
    @Volatile var hoverY: Float = -1f
    @Volatile var dirty: Boolean = true

    private var lastClockUpdateMs = 0L
    private val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
    private val buttons = ArrayList<HitButton>(24)

    // Pre-allocated Paints & Rects
    private val bgRect = RectF(16f, 16f, width - 16f, height - 16f)
    private val dockRect = RectF(260f, 610f, 1020f, 692f)
    private val tmpRect = RectF()

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = LinearGradient(
            0f, 0f, width.toFloat(), height.toFloat(),
            0xE60D131D.toInt(), 0xE6151E2E.toInt(), Shader.TileMode.CLAMP
        )
    }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.5f
        color = 0x5500E5FF.toInt()
    }
    private val cardPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x99192231.toInt() }
    private val dockPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xCC0A0F18.toInt() }
    private val pillFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val pillStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }

    private val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 36f
        typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
    }
    private val rowTitlePaint = Paint(titlePaint).apply { textSize = 25f }
    private val subPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFB0BEC5.toInt()
        textSize = 22f
    }
    private val statusPaint = Paint(subPaint).apply { color = 0xFF00E5FF.toInt() }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 21f
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
    }
    private val pillTextPaint = Paint(labelPaint).apply { textSize = 20f }

    fun renderIfNeeded(): Boolean {
        val now = SystemClock.uptimeMillis()
        if (now - lastClockUpdateMs > 1000L) {
            lastClockUpdateMs = now
            dirty = true
        }
        if (!dirty) return false
        dirty = false
        drawUi()
        return true
    }

    fun handleClick(nx: Float, ny: Float): Boolean {
        val x = nx * width
        val y = ny * height
        for (i in buttons.indices) {
            val b = buttons[i]
            if (b.rect.contains(x, y)) {
                b.action()
                dirty = true
                return true
            }
        }
        return false
    }

    fun updateHover(nx: Float, ny: Float) {
        val x = nx * width
        val y = ny * height
        if (kotlin.math.abs(x - hoverX) > 6f || kotlin.math.abs(y - hoverY) > 6f) {
            hoverX = x
            hoverY = y
            dirty = true
        }
    }

    private fun drawUi() {
        buttons.clear()
        canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
        canvas.drawRoundRect(bgRect, 36f, 36f, bgPaint)
        canvas.drawRoundRect(bgRect, 36f, 36f, borderPaint)

        val timeStr = timeFormat.format(Date())
        canvas.drawText("PocketVR OS", 54f, 74f, titlePaint)
        canvas.drawText("$timeStr  |  $arStatus  |  $handStatus  |  $fps FPS", 300f, 72f, statusPaint)

        drawPillButton("stereo", RectF(940f, 38f, 1085f, 84f), if (prefs.stereoEnabled) "VR: SBS" else "VR: MONO", 0xFF00E5FF.toInt()) {
            onToggleStereo()
        }
        drawPillButton("recenter", RectF(1100f, 38f, 1230f, 84f), "CENTER", 0xFF78909C.toInt()) {
            onRecenter()
        }

        when (currentTab) {
            PanelTab.HOME -> drawHomeTab()
            PanelTab.STORE -> drawStoreTab()
            PanelTab.CONNECTIONS -> drawConnectionsTab()
            PanelTab.PROMPT -> drawPromptTab()
        }

        drawBottomDock()
    }

    private fun drawHomeTab() {
        val installed = prefs.getInstalledIds()
        val items = StoreCatalog.getAll(prefs).filter { installed.contains(it.id) }

        canvas.drawText("Installed Apps & Games", 54f, 138f, subPaint)

        val cols = 4
        val startX = 160f
        val startY = 230f
        val stepX = 310f
        val stepY = 195f

        items.take(8).forEachIndexed { idx, item ->
            val col = idx % cols
            val row = idx / cols
            val cx = startX + col * stepX
            val cy = startY + row * stepY
            val size = 112f
            val hit = RectF(cx - 75f, cy - 75f, cx + 75f, cy + 85f)
            val hovered = hit.contains(hoverX, hoverY)

            VrIcons.drawIcon(canvas, cx, cy, if (hovered) size * 1.08f else size, item.iconType, item.accentColor, hovered)
            canvas.drawText(item.title, cx, cy + 80f, labelPaint)

            buttons.add(HitButton("app_${item.id}", hit) {
                onLaunchUrl(item.title, item.url)
            })
        }
    }

    private fun drawStoreTab() {
        canvas.drawText("Pocket Store — Games & Spatial Apps", 54f, 138f, titlePaint)
        drawPillButton("add_custom", RectF(960f, 102f, 1230f, 150f), "+ ADD GAME / APP", 0xFF00E676.toInt()) {
            onAddCustomAppDialog()
        }

        val installed = prefs.getInstalledIds()
        val all = StoreCatalog.getAll(prefs)
        var y = 185f

        all.take(5).forEach { item ->
            tmpRect.set(54f, y, 1226f, y + 76f)
            canvas.drawRoundRect(tmpRect, 18f, 18f, cardPaint)
            VrIcons.drawIcon(canvas, 102f, y + 38f, 54f, item.iconType, item.accentColor, false)

            canvas.drawText("${item.title}  [${item.category}]", 150f, y + 34f, rowTitlePaint)
            canvas.drawText(item.description, 150f, y + 62f, subPaint)

            val isInst = installed.contains(item.id)
            drawPillButton(
                "store_${item.id}",
                RectF(1030f, y + 14f, 1205f, y + 62f),
                if (isInst) "OPEN" else "INSTALL",
                if (isInst) 0xFF00E5FF.toInt() else 0xFF00E676.toInt()
            ) {
                if (isInst) onLaunchUrl(item.title, item.url) else prefs.setInstalled(item.id, true)
            }
            y += 88f
        }
    }

    private fun drawConnectionsTab() {
        canvas.drawText("Connections & VR Hardware", 54f, 138f, titlePaint)

        val wifiOk = isNetworkConnected()
        val gamepadCount = countGamepads()

        drawInfoCard(54f, 175f, 560f, 120f, "Wi-Fi / Internet", if (wifiOk) "Connected (Online)" else "Offline", if (wifiOk) 0xFF00E676.toInt() else 0xFFFF5252.toInt())
        drawInfoCard(650f, 175f, 576f, 120f, "Bluetooth / Gamepads", if (gamepadCount > 0) "$gamepadCount Controller(s) Active" else "No Gamepad Detected", 0xFF40C4FF.toInt())

        drawPillButton("toggle_6dof", RectF(54f, 330f, 420f, 400f), "6DoF ARCore: ${if (prefs.ar6DofEnabled) "ON" else "OFF"}", 0xFF00E5FF.toInt()) {
            onToggle6Dof()
        }
        drawPillButton("toggle_hands", RectF(450f, 330f, 850f, 400f), "MediaPipe Hands: ${if (prefs.handTrackingEnabled) "ON" else "OFF"}", 0xFFE040FB.toInt()) {
            onToggleHands()
        }

        canvas.drawText("IPD (Interpupillary Distance): ${prefs.ipdMm.toInt()} mm", 54f, 470f, titlePaint)
        drawPillButton("ipd_minus", RectF(54f, 495f, 190f, 555f), "- 2 mm", 0xFF78909C.toInt()) { prefs.ipdMm -= 2f }
        drawPillButton("ipd_plus", RectF(215f, 495f, 355f, 555f), "+ 2 mm", 0xFF78909C.toInt()) { prefs.ipdMm += 2f }
    }

    private fun drawPromptTab() {
        canvas.drawText("Prompt & Promo Hub", 54f, 138f, titlePaint)
        canvas.drawText("Quick AI Prompts & PocketVR OS Pro Access", 54f, 174f, subPaint)

        drawPillButton("prompt_gemini", RectF(54f, 210f, 610f, 290f), "OPEN AI PROMPT ASSISTANT", 0xFF40C4FF.toInt()) {
            onLaunchUrl("AI Prompt Hub", "https://gemini.google.com/")
        }
        drawPillButton("prompt_search", RectF(640f, 210f, 1226f, 290f), "GOOGLE VOICE / WEB SEARCH", 0xFF00E676.toInt()) {
            onLaunchUrl("Google", "https://www.google.com/")
        }

        val promoStatus = if (prefs.proUnlocked) "POCKETVR PRO: ACTIVATED" else "ACTIVATE PROMO: POCKETVR2026"
        drawPillButton("promo_btn", RectF(54f, 330f, 610f, 410f), promoStatus, 0xFFFFB74D.toInt()) {
            prefs.proUnlocked = true
        }
    }

    private fun drawBottomDock() {
        canvas.drawRoundRect(dockRect, 28f, 28f, dockPaint)
        val tabs = arrayOf(
            Triple(PanelTab.HOME, "HOME", 0xFF00E5FF.toInt()),
            Triple(PanelTab.STORE, "POCKET STORE", 0xFF00E676.toInt()),
            Triple(PanelTab.CONNECTIONS, "CONNECT", 0xFFE040FB.toInt()),
            Triple(PanelTab.PROMPT, "PROMPT", 0xFFFFB74D.toInt())
        )
        var x = 285f
        for (t in tabs) {
            val active = (currentTab == t.first)
            drawPillButton("tab_${t.first.name}", RectF(x, 622f, x + 170f, 680f), t.second, if (active) t.third else 0xFF455A64.toInt()) {
                currentTab = t.first
            }
            x += 180f
        }
    }

    private fun drawInfoCard(x: Float, y: Float, w: Float, h: Float, title: String, value: String, accent: Int) {
        tmpRect.set(x, y, x + w, y + h)
        canvas.drawRoundRect(tmpRect, 20f, 20f, cardPaint)
        canvas.drawText(title, x + 24f, y + 44f, rowTitlePaint)
        statusPaint.color = accent
        canvas.drawText(value, x + 24f, y + 88f, statusPaint)
        statusPaint.color = 0xFF00E5FF.toInt()
    }

    private fun drawPillButton(id: String, rect: RectF, text: String, accent: Int, action: () -> Unit) {
        val hovered = rect.contains(hoverX, hoverY)
        pillFill.color = if (hovered) accent else (accent and 0x00FFFFFF) or 0x33000000
        pillStroke.color = accent
        canvas.drawRoundRect(rect, 16f, 16f, pillFill)
        canvas.drawRoundRect(rect, 16f, 16f, pillStroke)

        pillTextPaint.color = if (hovered) 0xFF0A0F18.toInt() else Color.WHITE
        canvas.drawText(text, rect.centerX(), rect.centerY() + 7f, pillTextPaint)
        buttons.add(HitButton(id, rect, action))
    }

    private fun isNetworkConnected(): Boolean {
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val net = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(net) ?: return false
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } catch (_: Exception) { false }
    }

    private fun countGamepads(): Int {
        var count = 0
        for (id in InputDevice.getDeviceIds()) {
            val dev = InputDevice.getDevice(id) ?: continue
            val src = dev.sources
            if ((src and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
                (src and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK) {
                count++
            }
        }
        return count
    }
}
