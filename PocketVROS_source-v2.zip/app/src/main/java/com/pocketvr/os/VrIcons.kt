package com.pocketvr.os

import android.graphics.*

object VrIcons {
    private val rect = RectF()
    private val subRect = RectF()
    private val plate = Path()
    private val glyphPath = Path()

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val glyphPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val whiteFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }

    fun drawIcon(
        canvas: Canvas,
        cx: Float,
        cy: Float,
        size: Float,
        iconType: String,
        accentColor: Int,
        hovered: Boolean
    ) {
        val half = size * 0.5f
        rect.set(cx - half, cy - half, cx + half, cy + half)
        val cut = size * 0.22f

        plate.reset()
        plate.moveTo(rect.left + cut, rect.top)
        plate.lineTo(rect.right - cut, rect.top)
        plate.lineTo(rect.right, rect.top + cut)
        plate.lineTo(rect.right, rect.bottom - cut)
        plate.lineTo(rect.right - cut, rect.bottom)
        plate.lineTo(rect.left + cut, rect.bottom)
        plate.lineTo(rect.left, rect.bottom - cut)
        plate.lineTo(rect.left, rect.top + cut)
        plate.close()

        bgPaint.color = if (hovered) 0xEE1F2937.toInt() else 0xD6111722.toInt()
        canvas.drawPath(plate, bgPaint)

        borderPaint.strokeWidth = if (hovered) size * 0.055f else size * 0.032f
        borderPaint.color = if (hovered) accentColor else (accentColor and 0x00FFFFFF) or 0xAA000000.toInt()
        canvas.drawPath(plate, borderPaint)

        glyphPaint.color = Color.WHITE
        glyphPaint.strokeWidth = size * 0.065f
        fillPaint.color = accentColor

        val r = size * 0.24f
        when (iconType) {
            "TELEGRAM" -> {
                glyphPath.reset()
                glyphPath.moveTo(cx - r * 1.05f, cy + r * 0.05f)
                glyphPath.lineTo(cx + r * 1.05f, cy - r * 0.85f)
                glyphPath.lineTo(cx + r * 0.55f, cy + r * 0.95f)
                glyphPath.lineTo(cx - r * 0.1f, cy + r * 0.35f)
                glyphPath.close()
                canvas.drawPath(glyphPath, fillPaint)
                canvas.drawLine(cx - r * 0.1f, cy + r * 0.35f, cx + r * 0.9f, cy - r * 0.7f, glyphPaint)
            }
            "GOOGLE" -> {
                subRect.set(cx - r, cy - r, cx + r, cy + r)
                glyphPaint.color = accentColor
                canvas.drawArc(subRect, 35f, 290f, false, glyphPaint)
                glyphPaint.color = Color.WHITE
                canvas.drawLine(cx, cy, cx + r, cy, glyphPaint)
            }
            "YOUTUBE" -> {
                subRect.set(cx - r * 1.15f, cy - r * 0.78f, cx + r * 1.15f, cy + r * 0.78f)
                canvas.drawRoundRect(subRect, r * 0.3f, r * 0.3f, fillPaint)
                glyphPath.reset()
                glyphPath.moveTo(cx - r * 0.28f, cy - r * 0.36f)
                glyphPath.lineTo(cx + r * 0.44f, cy)
                glyphPath.lineTo(cx - r * 0.28f, cy + r * 0.36f)
                glyphPath.close()
                canvas.drawPath(glyphPath, whiteFill)
            }
            "STORE" -> {
                subRect.set(cx - r * 0.85f, cy - r * 0.35f, cx + r * 0.85f, cy + r * 0.95f)
                canvas.drawRoundRect(subRect, r * 0.2f, r * 0.2f, glyphPaint)
                subRect.set(cx - r * 0.45f, cy - r * 0.95f, cx + r * 0.45f, cy - r * 0.05f)
                canvas.drawArc(subRect, 180f, 180f, false, glyphPaint)
                canvas.drawCircle(cx, cy + r * 0.3f, r * 0.22f, fillPaint)
            }
            "CONNECT" -> {
                for (i in 1..3) {
                    val rr = r * (0.35f * i)
                    subRect.set(cx - rr, cy - rr + r * 0.35f, cx + rr, cy + rr + r * 0.35f)
                    glyphPaint.color = if (i == 3) accentColor else Color.WHITE
                    canvas.drawArc(subRect, 225f, 90f, false, glyphPaint)
                }
                canvas.drawCircle(cx, cy + r * 0.65f, r * 0.16f, fillPaint)
            }
            "PROMPT" -> {
                glyphPath.reset()
                glyphPath.moveTo(cx - r * 0.7f, cy - r * 0.45f)
                glyphPath.lineTo(cx - r * 0.1f, cy)
                glyphPath.lineTo(cx - r * 0.7f, cy + r * 0.45f)
                canvas.drawPath(glyphPath, glyphPaint)
                glyphPaint.color = accentColor
                canvas.drawLine(cx + r * 0.05f, cy + r * 0.45f, cx + r * 0.8f, cy + r * 0.45f, glyphPaint)
            }
            "GAME", "TARGET" -> {
                canvas.drawCircle(cx, cy, r * 0.85f, glyphPaint)
                canvas.drawCircle(cx, cy, r * 0.35f, fillPaint)
                canvas.drawLine(cx - r * 1.1f, cy, cx - r * 0.55f, cy, glyphPaint)
                canvas.drawLine(cx + r * 0.55f, cy, cx + r * 1.1f, cy, glyphPaint)
                canvas.drawLine(cx, cy - r * 1.1f, cx, cy - r * 0.55f, glyphPaint)
                canvas.drawLine(cx, cy + r * 0.55f, cx, cy + r * 1.1f, glyphPaint)
            }
            else -> {
                subRect.set(cx - r * 0.75f, cy - r * 0.75f, cx + r * 0.75f, cy + r * 0.75f)
                canvas.drawRect(subRect, glyphPaint)
                canvas.drawCircle(cx, cy, r * 0.25f, fillPaint)
            }
        }
    }
}
