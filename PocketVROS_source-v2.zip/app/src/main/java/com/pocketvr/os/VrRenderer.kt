package com.pocketvr.os

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.opengl.Matrix
import android.os.SystemClock
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

class VrRenderer(
    private val prefs: Prefs,
    private val arTracker: ArTracker,
    private val uiPanel: UiPanel
) : GLSurfaceView.Renderer {

    private var program = 0
    private var textureId = 0
    private var posHandle = 0
    private var texHandle = 0
    private var mvpHandle = 0

    private var surfaceW = 1
    private var surfaceH = 1

    // Pre-allocated matrices (Zero GC in onDrawFrame)
    private val projMatrix = FloatArray(16)
    private val viewMatrix = FloatArray(16)
    private val rotViewMatrix = FloatArray(16)
    private val modelMatrix = FloatArray(16)
    private val mvMatrix = FloatArray(16)
    private val mvpMatrix = FloatArray(16)
    private val headMatrix = FloatArray(16)

    // FPS tracking
    private var frameCount = 0
    private var lastFpsMs = SystemClock.uptimeMillis()

    private val quadCoords = floatArrayOf(
        -1.28f,  0.72f, 0f,
        -1.28f, -0.72f, 0f,
         1.28f,  0.72f, 0f,
         1.28f, -0.72f, 0f
    )
    private val texCoords = floatArrayOf(
        0f, 0f,
        0f, 1f,
        1f, 0f,
        1f, 1f
    )

    private val vertexBuffer: FloatBuffer = ByteBuffer.allocateDirect(quadCoords.size * 4)
        .order(ByteOrder.nativeOrder()).asFloatBuffer().apply { put(quadCoords); position(0) }

    private val texBuffer: FloatBuffer = ByteBuffer.allocateDirect(texCoords.size * 4)
        .order(ByteOrder.nativeOrder()).asFloatBuffer().apply { put(texCoords); position(0) }

    private val vShader = """
        uniform mat4 uMVP;
        attribute vec4 aPos;
        attribute vec2 aTex;
        varying vec2 vTex;
        void main() {
            vTex = aTex;
            gl_Position = uMVP * aPos;
        }
    """.trimIndent()

    private val fShader = """
        precision mediump float;
        uniform sampler2D uTex;
        varying vec2 vTex;
        void main() {
            gl_FragColor = texture2D(uTex, vTex);
        }
    """.trimIndent()

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0.05f, 0.07f, 0.11f, 1f)
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)

        val vs = compileShader(GLES20.GL_VERTEX_SHADER, vShader)
        val fs = compileShader(GLES20.GL_FRAGMENT_SHADER, fShader)
        program = GLES20.glCreateProgram().also {
            GLES20.glAttachShader(it, vs)
            GLES20.glAttachShader(it, fs)
            GLES20.glLinkProgram(it)
        }

        // Cache attribute/uniform locations once
        posHandle = GLES20.glGetAttribLocation(program, "aPos")
        texHandle = GLES20.glGetAttribLocation(program, "aTex")
        mvpHandle = GLES20.glGetUniformLocation(program, "uMVP")

        val ids = IntArray(1)
        GLES20.glGenTextures(1, ids, 0)
        textureId = ids[0]
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureId)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, uiPanel.bitmap, 0)

        Matrix.setIdentityM(modelMatrix, 0)
        Matrix.translateM(modelMatrix, 0, 0f, 0f, -2.0f)
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        surfaceW = width.coerceAtLeast(1)
        surfaceH = height.coerceAtLeast(1)
    }

    override fun onDrawFrame(gl: GL10?) {
        frameCount++
        val now = SystemClock.uptimeMillis()
        if (now - lastFpsMs >= 1000L) {
            uiPanel.fps = frameCount
            frameCount = 0
            lastFpsMs = now
        }

        arTracker.updateFrame()
        uiPanel.arStatus = arTracker.statusText

        if (uiPanel.renderIfNeeded()) {
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureId)
            GLUtils.texSubImage2D(GLES20.GL_TEXTURE_2D, 0, 0, 0, uiPanel.bitmap)
        }

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        GLES20.glUseProgram(program)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureId)
        GLES20.glEnableVertexAttribArray(posHandle)
        GLES20.glVertexAttribPointer(posHandle, 3, GLES20.GL_FLOAT, false, 0, vertexBuffer)
        GLES20.glEnableVertexAttribArray(texHandle)
        GLES20.glVertexAttribPointer(texHandle, 2, GLES20.GL_FLOAT, false, 0, texBuffer)

        arTracker.getHeadRotationMatrix(headMatrix)
        val ipdMeters = prefs.ipdMm * 0.001f

        if (prefs.stereoEnabled) {
            val halfW = surfaceW / 2
            drawEye(0, 0, halfW, surfaceH, -ipdMeters * 0.5f)
            drawEye(halfW, 0, halfW, surfaceH, ipdMeters * 0.5f)
        } else {
            drawEye(0, 0, surfaceW, surfaceH, 0f)
        }

        GLES20.glDisableVertexAttribArray(posHandle)
        GLES20.glDisableVertexAttribArray(texHandle)
    }

    private fun drawEye(x: Int, y: Int, w: Int, h: Int, eyeOffsetX: Float) {
        GLES20.glViewport(x, y, w, h)
        Matrix.perspectiveM(projMatrix, 0, 68f, w.toFloat() / h.toFloat(), 0.1f, 30f)

        Matrix.setIdentityM(viewMatrix, 0)
        Matrix.translateM(
            viewMatrix, 0,
            -arTracker.position[0] - eyeOffsetX,
            -arTracker.position[1],
            -arTracker.position[2]
        )

        Matrix.multiplyMM(rotViewMatrix, 0, headMatrix, 0, viewMatrix, 0)
        Matrix.multiplyMM(mvMatrix, 0, rotViewMatrix, 0, modelMatrix, 0)
        Matrix.multiplyMM(mvpMatrix, 0, projMatrix, 0, mvMatrix, 0)

        GLES20.glUniformMatrix4fv(mvpHandle, 1, false, mvpMatrix, 0)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
    }

    private fun compileShader(type: Int, src: String): Int {
        return GLES20.glCreateShader(type).also {
            GLES20.glShaderSource(it, src)
            GLES20.glCompileShader(it)
        }
    }
}
