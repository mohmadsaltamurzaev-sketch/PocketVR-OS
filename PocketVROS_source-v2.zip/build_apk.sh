#!/usr/bin/env bash
set -e
mkdir -p app/src/main/assets
if [ ! -f app/src/main/assets/hand_landmarker.task ]; then
  curl -fSL -o app/src/main/assets/hand_landmarker.task \
    https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task
fi
gradle assembleDebug --stacktrace
echo "APK ready at: app/build/outputs/apk/debug/app-debug.apk"
